#include "Car_list.h"
#ifdef __cplusplus 
extern "C" {
#endif
	void loadPos(current **HEAD, current **TAIL);
	void saveExit(current *tmp, int cost, char* exit_date );
	void savePos( current *HEAD);

#ifdef __cplusplus 
}
#endif

