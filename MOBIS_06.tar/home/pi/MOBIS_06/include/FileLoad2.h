// #include<map>
#ifndef FILELOAD2_H
#define FILELOAD2_H
#include "Car_list.h"
#include<map>
#include<iostream>
using namespace std;
void loadMem(map <string, string> &mem_map);
#endif
